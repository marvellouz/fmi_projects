﻿namespace FMI_EventsDemoScreens
{
    using System.Windows;
    using System.Windows.Controls;
    using System;

    //public delegate void NewStudentMarkEventHandler( object sender, AddStudentMarkEventArgs e );

    public partial class AddStudentMarkScreen : UserControl
    {
        //public event NewStudentMarkEventHandler NewStudentMark;
        public event EventHandler<AddStudentMarkEventArgs> NewStudentMark;

        public AddStudentMarkScreen()
        {
            this.InitializeComponent();

            this.SubmitButton.Click += new RoutedEventHandler( this.SubmitButton_Click );
        }

        protected virtual void OnNewStudentMark( AddStudentMarkEventArgs e )
        {
            // Check whether there are subscribers.
            if ( this.NewStudentMark != null )
            {
                // Raise event.
                this.NewStudentMark( this, e );
            }
        }

        private void SubmitButton_Click( object sender, RoutedEventArgs e )
        {
            // Create event args.
            AddStudentMarkEventArgs data = new AddStudentMarkEventArgs(
                this.NameField.Text,
                this.FacultyNumberField.Text,
                this.MarkSlider.Value );

            // Notify.
            this.OnNewStudentMark( data );

            // Clear fields.
            this.NameField.Clear();
            this.FacultyNumberField.Clear();
            this.MarkSlider.ClearValue( Slider.ValueProperty );
        }
    }
}