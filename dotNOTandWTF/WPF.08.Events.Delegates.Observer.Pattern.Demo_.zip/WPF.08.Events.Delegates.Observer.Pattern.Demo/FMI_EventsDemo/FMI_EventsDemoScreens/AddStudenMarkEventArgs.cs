﻿using System;

namespace FMI_EventsDemoScreens
{
    public class AddStudentMarkEventArgs : EventArgs
    {
        public AddStudentMarkEventArgs( string name, string fn, double mark )
        {
            this.Name = name;
            this.FacultyNumber = fn;
            this.Mark = mark;
        }

        public string Name
        {
            get;
            set;
        }

        public string FacultyNumber
        {
            get;
            set;
        }

        public double Mark
        {
            get;
            set;
        }
    }
}
