﻿namespace FMI_EventsDemoScreens
{
    using System.Windows.Controls;
    using System;
    using System.IO;

    public partial class HostScreen : UserControl
    {
        private event Action<int, DateTime> StudentAddedEvent;

        public HostScreen()
        {
            this.InitializeComponent();

            //this.AddStudentMarkControl.NewStudentMark += new NewStudentMarkEventHandler(AddStudentMark);

            this.AddStudentMarkControl.NewStudentMark += new EventHandler<AddStudentMarkEventArgs>( AddStudentMark );

            // With Action.
            this.StudentAddedEvent += new Action<int, DateTime>(UpdateTotalStudents);

            // With Anonymous delegate.
            this.StudentAddedEvent += delegate(int totalStudents, DateTime lastAdded)
            {
                this.LastAdded.Text = lastAdded.ToLongTimeString();
            };
        }

        private void UpdateTotalStudents(int totalStudents, DateTime lastAdded)
        {
            this.TotalStudents.Text = totalStudents.ToString();
        }

        private void AddStudentMark(object sender, AddStudentMarkEventArgs e)
        {
            string studentMark = string.Format("{0:#.##} {1}({2})", e.Mark, e.Name, e.FacultyNumber);
            this.StudentList.Items.Add(studentMark);

            // Raise event.
            this.StudentAddedEvent(this.StudentList.Items.Count, DateTime.Now);
        }
    }
}