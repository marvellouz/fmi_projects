﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FMI_EventsDemoScreens
{
    /// <summary>
    /// Interaction logic for Delegates.xaml
    /// </summary>
    public partial class Delegates : UserControl
    {
        public Delegates()
        {
            this.InitializeComponent();
        }

        public delegate int Function(ref int x);

        public int Calculate(Function f, ref int x)
        {
            return f(ref x);
        }

        private int Square(ref int x)
        {
            x = x * x;
            return x;
        }

        private int Cubic(ref int x)
        {
            return x * x * x;
        }

        private int Sqrt(ref int x)
        {
            return (int)Math.Sqrt(x);
        }

        private void PerformCalculations(object sender, RoutedEventArgs e)
        {
            List<int> data = new List<int>() { 0, 1, 2, 3 };

            Function f = new Function(this.Square);
            f += this.Cubic;
            f += this.Sqrt;


            f -= Square;
            f-= Cubic;
            f-= Sqrt;

            int n = 2;
            int x = Calculate( f, ref n );
            List<int> result = new List<int>();
            //foreach (int item in data)
            //{
            //    result.Add(Calculate(f, ref item));
            //}

            ResultList.ItemsSource = result;
        }

        private void ActionDemo(object sender, RoutedEventArgs e)
        {
            List<int> data = new List<int>() { 0, 1, 2, 3 };

            List<int> squareData = new List<int>();
            data.ForEach(delegate(int n)
            {
                squareData.Add(n * n);
            });

            ResultList.ItemsSource = squareData;
        }

        private void FuncDemo(object sender, RoutedEventArgs e)
        {
            List<int> data = new List<int>() { 0, 1, 2, 3 };

            IEnumerable<int> squareData = data.Select(delegate(int n)
            {
                return n * n;
            });

            ResultList.ItemsSource = squareData;
        }

        private void PredicateDemo(object sender, RoutedEventArgs e)
        {
            List<int> data = new List<int>() { 0, -1, 2, 3, -5, 10 };

            List<int> positives = data.FindAll(PositiveFilter);

            ResultList.ItemsSource = positives;
        }

        private bool PositiveFilter(int num)
        {
            return num > 0;
        }
    }
}