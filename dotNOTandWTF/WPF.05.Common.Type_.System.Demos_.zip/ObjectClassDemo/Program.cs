﻿using System;

namespace ObjectClassDemo
{
    class Box
    {
        public string Color { get; set; }
        public int Capacity { get; set; }
        public string[] Items { get; set; }

        public Box(string color, int capacity)
        {
            this.Color = color;
            this.Capacity = capacity;
            this.Items = new string[this.Capacity];
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj.GetType() != typeof(Box))
            {
                return false;
            }

            Box box = (Box)obj;
            if (this.Color != box.Color)
            {
                return false;
            }

            if (this.Capacity != box.Capacity)
            {
                return false;
            }

            return true;
        }

        public override int GetHashCode()
        {
            return this.Color.GetHashCode() ^ this.Capacity;
        }

        public override string ToString()
        {
            return string.Format("Box({0}, {1})", this.Color, this.Capacity);
        }
    }

    class Program
    {

        static void Main(string[] args)
        {
            Box box1 = new Box("Red", 20);
            Box box2 = new Box("Red", 20);
            Box box3 = box1;

            // Equals()
            Console.WriteLine(box1.Equals(box2));
            Console.WriteLine(box1.Equals(box3));
            Console.WriteLine(Box.Equals(box1, box3));

            // operator ==
            Console.WriteLine(box1 == box2);
            Console.WriteLine(box1 == box3);

            // ReferenceEquals()
            Console.WriteLine(Box.ReferenceEquals(box1, box2));
            Console.WriteLine(Box.ReferenceEquals(box1, box3));

            // GetHashCode()
            Console.WriteLine(box1.GetHashCode());
            Console.WriteLine(box2.GetHashCode());

            // ToString()
            Console.WriteLine(box1.ToString());
        }
    }
}