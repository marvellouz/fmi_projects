﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExplicitTypeCasting
{
    class Employee { }

    class Manager : Employee { }

    class Program
    {
        static void Main(string[] args)
        {
            Manager m = new Manager();
            PromoteEmployee(m);

            DateTime newYears = new DateTime(2010, 1, 1);
            PromoteEmployee(newYears); // получава се изключение
        }

        static void PromoteEmployee(Object o)
        {
            Employee e = (Employee)o;
            // логика
        }
    }
}
