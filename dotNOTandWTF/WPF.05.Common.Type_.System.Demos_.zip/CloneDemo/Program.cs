﻿using System;
using System.Text;

namespace CloneDemo
{
    class Box : ICloneable
    {
        public string Color { get; set; }
        public int Capacity { get; set; }
        public string[] Items { get; set; }

        public Box(string color, int capacity)
        {
            this.Color = color;
            this.Capacity = capacity;
            this.Items = new string[this.Capacity];
        }

        public object Clone()
        {
            Box result = new Box(this.Color, this.Capacity);
            Array.Copy(this.Items, result.Items, this.Capacity);

            return result;
        }

        public override string ToString()
        {
            StringBuilder itemsListBuilder = new StringBuilder();
            foreach (string item in this.Items)
            {
                if (!string.IsNullOrEmpty(item))
                {
                    itemsListBuilder.AppendFormat("{0}, ", item);
                }
            }

            string itemsList;
            if (itemsListBuilder.Length != 0)
            {
                itemsList = itemsListBuilder.ToString().Substring(0, itemsListBuilder.Length - 2);
            }
            else
            {
                itemsList = string.Empty;
            }

            return string.Format("Box({0}, {1}, Items: {2});", this.Color, this.Capacity, itemsList);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Box box1 = new Box("Red", 10);

            box1.Items[0] = "book";
            box1.Items[1] = "notepad";
            box1.Items[2] = "notepad";

            Console.WriteLine(box1);

            Box box2 = (Box)box1.Clone();
            box2.Color = "Blue";
            box2.Items[1] = "newspaper";

            Console.WriteLine(box1);
            Console.WriteLine(box2);
        }
    }
}
