﻿using System;
using System.Text;

namespace IComparableDemo
{
    class Box : IComparable
    {
        public string Color { get; set; }
        public int Capacity { get; set; }
        public string[] Items { get; set; }

        public Box(string color, int capacity)
        {
            this.Color = color;
            this.Capacity = capacity;
            this.Items = new string[this.Capacity];
        }

        int IComparable.CompareTo(object obj)
        {
            if (!(obj is Box))
            {
                throw new ArgumentException("The object is not a Box");
            }

            Box box = obj as Box;
            if (this.Capacity.CompareTo(box.Capacity) == 0)
            {
                return this.Color.CompareTo(box.Color);
            }

            return this.Capacity.CompareTo(box.Capacity);
        }

        public override string ToString()
        {
            return string.Format("Box({0}, {1});", this.Capacity, this.Color);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Box[] boxes = { new Box("Red", 10), new Box("Blue", 9), new Box("Blue", 13), new Box("Red", 13) };

            foreach (var box in boxes)
            {
                Console.WriteLine(box);
            }

            Array.Sort(boxes);

            Console.WriteLine();

            foreach (var box in boxes)
            {
                Console.WriteLine(box);
            }
        }
    }
}
