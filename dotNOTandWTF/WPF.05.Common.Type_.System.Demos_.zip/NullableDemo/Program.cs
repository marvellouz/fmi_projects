﻿using System;

namespace NullableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int? num = null;
            int y;

            if (num.HasValue)
            {
                Console.WriteLine("num = " + num.Value);
            }
            else
            {
                Console.WriteLine("num = Null");
            }

            //y става 0
            y = num.GetValueOrDefault();
            Console.WriteLine(y);

            //y става 1
            y = num.GetValueOrDefault(1);
            Console.WriteLine(y);
            
            try
            {
                y = num.Value;
            }
            catch (System.InvalidOperationException e)
            {
                System.Console.WriteLine(e.Message);
            }

            int? x = y;
            int z = -1;

            try
            {
                z = x.Value;
            }
            catch (System.InvalidOperationException e)
            {
                System.Console.WriteLine(e.Message);
            }
            
            Console.WriteLine(z);
        }
    }
}
