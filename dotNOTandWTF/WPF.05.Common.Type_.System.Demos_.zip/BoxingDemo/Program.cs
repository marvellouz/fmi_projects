﻿using System;

namespace BoxingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int value1 = 1;

            // извършва се опаковане
            object obj = value1;

            // променя се само стойността в стека
            value1 = 12345;

            // извършва се разопаковане
            int value2 = (int)obj;  
            Console.WriteLine(value2);

            // разопаковане
            long value3 = (long)(int)obj;
            //long value4 = (long)obj;
        }
    }
}
