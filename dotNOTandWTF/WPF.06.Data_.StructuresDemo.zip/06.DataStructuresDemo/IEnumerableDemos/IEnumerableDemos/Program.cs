﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace IEnumerableDemos
{
	class Program
	{
		static void Main(string[] args)
		{
			// Демо 1 - Имплементиране на машина за ябълки
			foreach (var apple in new AppleMachine(5, 10))
			{
				Console.WriteLine(apple);
			}
		}

		// Демо 1: Машина за ябълки
		#region Демо 1: Машина за ябълки

		class AppleMachine : IEnumerable<Apple>
		{
			private int minIndex;
			private int maxIndex;

			public AppleMachine() : this(0, -1) { }

			public AppleMachine(int to) : this(0, to) { }

			public AppleMachine(int from, int to)
			{
				minIndex = from;
				maxIndex = to;
			}

			public IEnumerator<Apple> GetEnumerator()
			{
				return new AppleEnumerator(this);
			}

			IEnumerator IEnumerable.GetEnumerator()
			{
				return new AppleEnumerator(this);
			}

			private class AppleEnumerator : IEnumerator<Apple>
			{
				AppleMachine machine;
				int currentIndex;

				private bool GenerateApple()
				{
					if (machine.maxIndex == -1 || currentIndex < machine.maxIndex)
					{
						Current = new Apple(currentIndex++);
						return true;
					}
					else
					{
						Current = null;
						return false;
					}
				}

				public AppleEnumerator(AppleMachine machine)
				{
					this.machine = machine;
					this.Reset();					
				}

				public Apple Current { get; private set; }

				public void Dispose()
				{
					Current = null;
					currentIndex = -1;
					machine = null;
				}

				object IEnumerator.Current
				{
					get { return Current; }
				}

				public bool MoveNext()
				{
					return GenerateApple();
				}

				public void Reset()
				{
					currentIndex = machine.minIndex;
					GenerateApple();
				}
			}
		}
		#endregion Демо 1: Машина за ябълки

		// Демо 2: Прости числа
		#region Демо 2: Прости числа
		static bool IsPrime(int p)
		{
			if (p < 2)
			{
				return false;
			}
			for (int i = 2; i < p / 2; i++)
			{
				if (p % i == 0)
				{
					return false;
				}
			}
			return true;
		}

		static IEnumerable<int> GeneratePrimes()
		{
			int i = 0;
			while (true)
			{
				if (IsPrime(i))
				{
					yield return i;
				}
				i++;
			}
		}
		#endregion Демо 2: Прости числа

		// Демо 3: Решения на задачата за ябълките
		#region Демо 3: Решения на задачата за ябълките
		// Решение 0 - най-често използвания начин
		static IEnumerable<Apple> GiveMeApples0(int count)
		{
			List<Apple> apples = new List<Apple>();
			for (int i = 0; i < count; i++)
			{
				apples.Add(new Apple(i));
			}
			return apples;
		}

		// Решение 1 - най-тежкия начин
		static IEnumerable<Apple> GiveMeApples1(int count)
		{
			return new AppleMachine(count);
		}

		// Решение 2 - съкратения начин
		static IEnumerable<Apple> GiveMeApples2(int count)
		{
			for (int i = 0; i < count; i++)
			{
				yield return new Apple(i);
			}
		}

		// Решение 3 - начинът, който обичам!
		static IEnumerable<Apple> GiveMeApples3(int count)
		{
            return Enumerable.Range(0, count).Select(i => new Apple(i));
            //return Enumerable.Select(Enumerable.Range(0, count),(i => new Apple(i)));
		}
		#endregion Демо 3: Решения на задачата за ябълките

		class Apple
		{
			private int index;
			public Apple(int i)
			{
				index = i;
			}

			public override string ToString()
			{
				return string.Format("[Apple {0}]", index);
			}
		}
	}
}
