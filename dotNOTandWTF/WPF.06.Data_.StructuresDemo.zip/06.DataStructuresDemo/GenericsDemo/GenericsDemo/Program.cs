﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace GenericsDemo
{
	class Program
	{
		static void Main(string[] args)
		{
			#region Generics
			// Демо 1
			//SimpleGenericsDemo();
			// Демо 2
			MultipleParametersAndConstraints();
			#endregion Generics

			#region Generic колекции и интерфейси

			// Nullable<T>
			//NullableTypeDemo();
			// Stack<T>, Queue<T>
			//StackAndQueueDemo();
			// LinkedList<T>
			//LinkedListDemo();
			// List<T>
			//ListDemo();
			// SortedList<K, V>, KeyValuePair<K, V>, имплементиране на IComparer<T>, Comparer<T>
			SorderListDemo();
			// Dictionary<K, V>, имплементиране на  IEqualityComparer<T>, EqualityComparer<T>
			//DictionaryDemo();
			// SortedDictionary<K, V>
			//SorderDictionaryDemo();
			#endregion Generic колекции и интерфейси
		}

		#region Generics
		// Демонстрация 1 - фабрика за generic обекти
		#region Демо 1
		private static void SimpleGenericsDemo()
		{
			var c1 = ContainerFactory.GetContainer(10);
			var c2 = ContainerFactory.GetContainer<double>(10);
			var c3 = ContainerFactory.GetContainer<decimal>(10);

			Console.WriteLine(
				string.Format("c1= {0}: {1}, c2= {2}: {3}, c3= {4}: {5}",
					c1.GetValue(), c1,
					c2.GetValue(), c2,
					c3.GetValue(), c3));
		}

		interface IContainer<T>
		{
			T GetValue();
		}

		class ContainerFactory
		{
			public static IContainer<T> GetContainer<T>(T value)
			{
				return new Container<T>(value);
			}

			private class Container<T> : IContainer<T>
			{
				public Container(T v)
				{
					this.value = v;
				}

				private T value;
				public T GetValue()
				{
					return this.value;
				}

				public override string ToString()
				{
					return typeof(T).ToString();
				}
			}
		}
		#endregion Демо 1

		// Демонстрация 2 - наредена двойка
		#region Демо 2
		private static void MultipleParametersAndConstraints()
		{
			var store = new Store<int, string>(10);
			store.Add("ASDF");
			store.Add(1, "QWER");
			Console.WriteLine(store.GetValue(0));
		}

		class KeyValuePair<K, V> where K : IComparable
		{
			public K Key { get; set; }
			public V Value { get; set; }
		}

		class Store<K, V>
			where K : IComparable, new()
		{
			KeyValuePair<K, V>[] store;
			int size;

			public Store(int capacity)
			{
				this.store = new KeyValuePair<K, V>[capacity];
				this.size = 0;
			}

			public KeyValuePair<K, V> Add(V value)
			{
				return Add(new K(), value);
			}

			public KeyValuePair<K, V> Add(K key, V value)
			{
				var pair = new KeyValuePair<K, V> { Key = key, Value = value };
				this.store[this.size++] = pair;
				return pair;
			}

			public V GetValue(K key)
			{
				foreach (var kvp in this.store)
				{
					if (kvp.Key.CompareTo(key) == 0)
					{
						return kvp.Value;
					}
				}

				return default(V);
			}
		}

		#endregion Демо 2

		#endregion Generics

		#region Generic колекции и интерфейси

		// Nullable<T>
		static void NullableTypeDemo()
		{
			Console.WriteLine("Nullable demo");
			Console.WriteLine("=============");

			Nullable<int> a = null;
			Console.WriteLine("a={0}", a);
			a = 10;
			Console.WriteLine("a={0}; a is {1}", a, a.GetType());
			int? b = new Nullable<int>(3);
			Console.WriteLine("b={0}; b is {1}", b, b.GetType());

			Console.WriteLine("Nullable<int> is {0}; int? is {1}", typeof(Nullable<int>), typeof(int?));
		}

		// Stack<T>, Queue<T>
		static void StackAndQueueDemo()
		{
			Console.WriteLine("Stack and Queue demo");
			Console.WriteLine("====================");
			// Stack<T>. Стекът е FILO = First input last output.
			Console.WriteLine("Stack demo");
			Console.WriteLine("----------");
			Stack<int> stack = new Stack<int>();
			stack.Push(3);
			stack.Push(4);
			stack.Push(5);
			Console.WriteLine("Stack peek: {0}, Count: {1}", stack.Peek(), stack.Count);
			Console.WriteLine("Stack pop: {0}, Count: {1}", stack.Pop(), stack.Count);
			Console.WriteLine("Stack peek: {0}, Count: {1}", stack.Peek(), stack.Count);
			Console.WriteLine("Stack pop: {0}, Count: {1}", stack.Pop(), stack.Count);
			Console.WriteLine("Stack peek: {0}, Count: {1}", stack.Peek(), stack.Count);
			stack.Push(6);
			Console.WriteLine("Stack peek: {0}, Count: {1}", stack.Peek(), stack.Count);

			Console.WriteLine("Queue demo");
			Console.WriteLine("----------");

			Queue<int> queue = new Queue<int>();
			queue.Enqueue(3);
			queue.Enqueue(4);
			queue.Enqueue(5);
			Console.WriteLine("Queue peek: {0}, Count: {1}", queue.Peek(), queue.Count);
			Console.WriteLine("Queue pop: {0}, Count: {1}", queue.Dequeue(), queue.Count);
			Console.WriteLine("Queue peek: {0}, Count: {1}", queue.Peek(), queue.Count);
			Console.WriteLine("Queue pop: {0}, Count: {1}", queue.Dequeue(), queue.Count);
			Console.WriteLine("Queue peek: {0}, Count: {1}", queue.Peek(), queue.Count);
			queue.Enqueue(6);
			Console.WriteLine("Queue peek: {0}, Count: {1}", queue.Peek(), queue.Count);
		}

		// LinkedList<T>
		static void LinkedListDemo()
		{
			Console.WriteLine("LinkedList demo:");
			Console.WriteLine("=================");
			LinkedList<string> names = new LinkedList<string>();
			names.AddLast("Last");
			names.AddFirst("Middle");
			var first = new LinkedListNode<string>("First");
			names.AddFirst(first);
			var e = names.Find("First");
			Console.WriteLine("Element with value \"First\" is{0} equal to the first item.", e == first ? "" : "n't");
			Console.WriteLine("Elements: ");
			foreach (var el in names)
			{
				Console.Write("\"{0}\", ", el);
			}
			Console.WriteLine();
			names.Remove("Middle");
			Console.WriteLine("Elements: ");
			foreach (var el in names)
			{
				Console.Write("\"{0}\", ", el);
			}
			Console.WriteLine();
			names.RemoveLast();
			Console.WriteLine("Elements: ");
			foreach (var el in names)
			{
				Console.Write("\"{0}\", ", el);
			}
			Console.WriteLine();
		}

		// List<T>
		static void ListDemo()
		{
			Console.WriteLine("List demo:");
			Console.WriteLine("==========");

			List<double> doubles = new List<double> { 1, 2, 3 };
			doubles.Add(11);
			Print(doubles);

			doubles.AddRange(doubles);

			Print(doubles);

			doubles[3] = doubles[2];

			Print(doubles);

			doubles.Sort();

			Print(doubles);

			doubles.Sort(new Comparison<double>((a, b) => b > a ? 1 : a > b ? -1 : 0));

			Print(doubles);

			doubles.ForEach(e => Console.WriteLine("e = {0}, ", e));
		}

		// SortedList<K, V>, имплементиране на IComparer<T>
		#region SortedList<K, V>, имплементиране на IComparer<T>
		static void SorderListDemo()
		{
			SortedList<int, string> sortedList1 = new SortedList<int, string>(Comparer<int>.Default);

			////sortedList1.Add(10, "First string");
			////sortedList1.Add(20, "Second string");
			////sortedList1.Add(11, "Third string");
			////sortedList1.Add(13, "Forth string");

			////Print(sortedList1);

			// Part 1

			SortedList<int, string> sortedList = new SortedList<int, string>(CustomComparer.Instance);

			sortedList.Add(10, "First string");
			sortedList.Add(20, "Second string");
			sortedList.Add(11, "Third string");
			sortedList.Add(13, "Forth string");

			Print(sortedList);

			// Part 2
			//sortedList.Add(10, "ADSF");

			// Part 3
			//Console.WriteLine("List[1] = {0}", sortedList[1]);
			//Console.WriteLine("List[10] = {0}", sortedList[10]);
		}

		class CustomComparer : IComparer<int>
		{
			private static CustomComparer instance;
			public static CustomComparer Instance
			{
				get
				{
					if (instance == null)
					{
						instance = new CustomComparer();
					}
					return instance;
				}
			}

			private CustomComparer() { }

			public int Compare(int x, int y)
			{
				return y - x;
			}
		}
		#endregion SortedList<K, V>, имплементиране на IComparer<T>

		// Dictionary<K, V>, имплементиране на  IEqualityComparer<T>, EqualityComparer<T>
		#region Dictionary<K, V>, имплементиране на  IEqualityComparer<T>, EqualityComparer<T>
		static void DictionaryDemo()
		{
			// Part 1
			Dictionary<string, double> studentMarks = new Dictionary<string, double>(); // Same as new Dictionary<string, double>(EqualityComparer<string>.Default)
			studentMarks.Add("Иван Иванов", 3.5);
			studentMarks.Add("Петър Петров", 4.5);
			studentMarks.Add("Иван Петров", 6.0);
			studentMarks.Add("Петър Иванов", 2.0);

			Print(studentMarks);

			// Part 2
			//Console.WriteLine("Петър Петров: {0}", studentMarks["Петър Петров"]);
			//Console.WriteLine("Петър Иванов: {0}", studentMarks["Петър Иванов"]);
			//Console.WriteLine("Петър: {0}", studentMarks["Петър"]);

			// Part 3
			studentMarks = new Dictionary<string, double>(CustomEqualityComparer.Instance);
			studentMarks.Add("Иван Иванов", 3.5);
			studentMarks.Add("Петър Петров", 4.5);
			//studentMarks.Add("Иван Петров", 6.0);
			//studentMarks.Add("Петър Иванов", 2.0);

			//Print(studentMarks);

			//Console.WriteLine("Петър Петров: {0}", studentMarks["Петър Петров"]);
			//Console.WriteLine("Петър Иванов: {0}", studentMarks["Петър Иванов"]);
			//Console.WriteLine("Петър: {0}", studentMarks["Петър"]);

			//studentMarks = new Dictionary<string, double>(studentMarks, CustomEqualityComparer.Instance);

			//Console.WriteLine(studentMarks.ContainsKey("Петър"));
		}

		class CustomEqualityComparer : IEqualityComparer<string>
		{
			private static CustomEqualityComparer instance;
			public static CustomEqualityComparer Instance
			{
				get
				{
					if (instance == null)
					{
						instance = new CustomEqualityComparer();
					}
					return instance;
				}
			}

			private CustomEqualityComparer() { }

			public bool Equals(string x, string y)
			{
				string[] namesX = x.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
				return y.StartsWith(namesX[0]);
			}

			public int GetHashCode(string obj)
			{
				return (obj.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries))[0].GetHashCode();
			}
		}
		#endregion Dictionary<K, V>, имплементиране на  IEqualityComparer<T>, EqualityComparer<T>

		// SortedDictionary<K, V>
		static void SorderDictionaryDemo()
		{
			SortedDictionary<double, string> sortedMarks = new SortedDictionary<double, string>();
			sortedMarks.Add(3.5, "Иван Петров");
			sortedMarks.Add(5.5, "Петър Петров");
			sortedMarks.Add(2.0, "Иван Иванов");

			Print(sortedMarks);

			Print(sortedMarks.Keys);

			Print(sortedMarks.Values);
		}

		#endregion Generic колекции и интерфейси

		static void Print<T>(IEnumerable<T> en)
		{
			Console.Write("Elements: ");
			foreach (var e in en)
			{
				Console.Write("{0}, ", e);
			}
			Console.WriteLine();
		}
	}
}