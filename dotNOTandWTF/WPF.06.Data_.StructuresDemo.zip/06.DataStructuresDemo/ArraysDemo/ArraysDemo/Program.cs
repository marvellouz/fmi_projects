﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace ArraysDemo
{
	class Program
	{
		static void Main(string[] args)
		{
			// Демонстрациио от 1 до 4
			#region Масиви
			// Масиви
			// Демо 1
			//SingleDimensionalArraysDemo();
			// Демо 2
			//ForeachDemo();
			// Демо 3
			//ArrayOfObjects();
			// Демо 4
			//JaggedArraysDemo();
			// Демо 5
			//SystemArrayDemo();


			int[] arr = new int[] { 5, 3, 10 };
			System.Array.Sort(arr);

			foreach (var a in arr)
			{
				Console.Write("{0}, ", a);
			}

			#endregion Масиви
		}

		// Демонстрациио от 1 до 4
		#region Масиви
		// Демонстрация #1
		static void SingleDimensionalArraysDemo()
		{
			// Инициализация
			int[] array = new int[] { 3, 11, 2, -1, 8, 10 };


			for (int i = 0; i < array.Length; i++)
			{
				for (int j = i + 1; j < array.Length; j++)
				{
					if (array[i] > array[j])
					{
						int c = array[i];
						array[i] = array[j];
						array[j] = c;
					}
				}
			}

			// Изпечатване на екрана
			for (int i = 0; i < array.Length; i++)
			{
				Console.WriteLine(string.Format("array[{0}]={1};", i, array[i]));
			}
		}

		// Демонстрация #2
		private static void ForeachDemo()
		{
			// Инициализация.
			int[] array = new int[] { 3, 11, 2, -1, 8, 10 };

			// Обхождане на масива посредством конструкцията foreach.
			foreach (int a in array)
			{
				Console.Write(string.Format("{0}, ", a));
			}
			Console.WriteLine();
		}

		// Демонстрация #3
		#region Демонстрация #3
		private static void ArrayOfObjects()
		{
			Base[] array = new Base[5];
			array[0] = new Base();
			array[1] = new Derived1();
			array[2] = new Derived2();
			array[3] = new Base();
			array[4] = new Derived1();

			foreach (var b in array)
			{
				Console.Write(string.Format("{0}, ", b));
			}
			Console.WriteLine();
		}

		class Base
		{
			public override string ToString()
			{
				return "Base";
			}
		}

		class Derived1 : Base
		{
			public override string ToString()
			{
				return "Derived1";
			}
		}

		class Derived2 : Base
		{
			public override string ToString()
			{
				return "Derived2";
			}
		}
		#endregion Демонстрация #3

		// Демонстрация #4
		private static void JaggedArraysDemo()
		{
			int[][] jaggedArray =
				new int[][] 
				{ 
					new int[] { 1, 2, 3 }, 
					new int[] { 4, 5 } 
				};

			jaggedArray[0][1] = 3;
			foreach (int[] a in jaggedArray)
			{
				foreach (int v in a)
				{
					Console.Write(v + ", ");
				}
				Console.WriteLine();
			}
		}

		// Демонстрация #5
		private static void SystemArrayDemo()
		{
			#region Cast to System.Array and to IEnumerable
			Console.WriteLine("Cast arrays to System.Array and to IEnumerable: ");
			System.Array arr = new int[] { 1, 2, 3 };
			IEnumerable arr1 = arr;

			foreach (var a in arr)
			{
				Console.Write(a + ", ");
			}
			Console.WriteLine();

			foreach (var a in arr1)
			{
				Console.Write(a + ", ");
			}
			Console.WriteLine();
			#endregion Cast to System.Array and to IEnumerable

			#region Array bounds
			Console.WriteLine("Array bounds: ");
			int[,] array = (int[,])System.Array.CreateInstance(typeof(int), new int[] { 2, 2 }, new int[] { 1, 2 });
			for (int i = 0; i < array.Rank; i++)
			{
				Console.WriteLine(
					string.Format("Dimension {0}: starts at {1} and ends at {2}",
									i,
									array.GetLowerBound(i),
									array.GetUpperBound(i)));
			}
			#endregion Array bounds
		}
		#endregion Масиви
	}
}
