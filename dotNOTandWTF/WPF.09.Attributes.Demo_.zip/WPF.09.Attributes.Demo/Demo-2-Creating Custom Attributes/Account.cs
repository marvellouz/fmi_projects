﻿using System.Collections;
using System.Diagnostics;

// Here you attach the AuthorAttribute user-defined custom attribute to 
// the Account class. The unnamed string argument is passed to the 
// AuthorAttribute class's constructor when creating the attributes.
[Author( "Joe Programmer" )]
[DebuggerDisplay( "Orders: (Name)" )]
class Account
{
    // Attach the IsTestedAttribute custom attribute to this method.
    [IsTested]
    public void AddOrder( Order orderToAdd )
    {
        orders.Add( orderToAdd );
    }

    public void AddFunds()
    {
    }

    public string Name { get; set; }
    private ArrayList orders = new ArrayList();
}
