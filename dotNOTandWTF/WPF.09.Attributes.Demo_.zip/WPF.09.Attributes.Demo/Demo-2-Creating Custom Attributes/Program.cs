﻿using System;
using System.Reflection;

class Program
{
    private static bool IsMemberTested( MemberInfo member )
    {
        foreach ( object attribute in member.GetCustomAttributes( true ) )
        {
            if ( attribute is IsTestedAttribute )
            {
                return true;
            }
        }
        return false;
    }

    private static void DumpAttributes( MemberInfo member )
    {
        Console.WriteLine( "Attributes for : " + member.Name );
        foreach ( object attribute in member.GetCustomAttributes( true ) )
        {
            Console.WriteLine( attribute );
        }
    }

    public static void Main()
    {
        Order o = new Order();
        

        // display attributes for Account class
        //DumpAttributes( typeof( Order ) );

        // display list of tested members
        //foreach ( MethodInfo method in ( typeof( Account ) ).GetMethods() )
        //{
        //    if ( IsMemberTested( method ) )
        //    {
        //        Console.WriteLine( "Member {0} is tested!", method.Name );
        //    }
        //    else
        //    {
        //        Console.WriteLine( "Member {0} is NOT tested!", method.Name );
        //    }
        //}
        //Console.WriteLine();

        //// display attributes for Order class
        DumpAttributes( typeof( Order ) );

        // display attributes for methods on the Order class
        foreach ( MethodInfo method in ( typeof( Order ) ).GetMethods() )
        {
            if ( IsMemberTested( method ) )
            {
                Console.WriteLine( "Member {0} is tested!", method.Name );
            }
            else
            {
                Console.WriteLine( "Member {0} is NOT tested!", method.Name );
            }
        }
        Console.WriteLine();
    }
}
