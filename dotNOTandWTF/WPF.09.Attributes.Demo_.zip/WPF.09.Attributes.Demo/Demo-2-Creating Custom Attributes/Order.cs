﻿// Attach the AuthorAttribute and IsTestedAttribute custom attributes 
// to this class.
// Note the use of the 'Version' named argument to the AuthorAttribute.
using System.Diagnostics;
[Author( "Jane Programmer", Version = 2 ), IsTested()]
[DebuggerDisplay( "Orders: {Name}" )]
class Order
{
    public string Name { get; set; }
    // add stuff here ...
}
