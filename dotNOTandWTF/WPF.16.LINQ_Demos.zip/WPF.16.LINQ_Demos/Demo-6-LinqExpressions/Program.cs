﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Demo_6_LinqExpressions
{
    class Program
    {
        static void Main()
        {
            List<int> numbers = new List<int>();

            for (int i = 0; i < 10; i++)
            {
                numbers.Add(i);
            }

            Filter(numbers);

            Projection(numbers);

            Sorting(numbers);

            Grouping(numbers);

            Aggregators(numbers);
        }

        public static void Filter(List<int> numbers)
        {
            // Declarative syntax
            var positiveEven = from num in numbers
                               where num > 0 && num % 2 == 0
                               select num;

            positiveEven.ToList().ForEach(x => Console.Write("{0} ", x));
            Console.WriteLine();

            // Method call syntax
            var positiveEven2 = numbers.Where(x => x > 0 && x % 2 == 0);

            positiveEven2.ToList().ForEach(x => Console.Write("{0} ", x));
            Console.WriteLine();
        }

        public static void Projection(List<int> numbers)
        {
            // Declarative syntax
            var squares = from num in numbers
                          select num * num;


            squares.ToList().ForEach(x => Console.Write("{0} ", x));
            Console.WriteLine();

            // Method call syntax
            var squares2 = numbers.Select(x => x * x);

            squares2.ToList().ForEach(x => Console.Write("{0} ", x));
            Console.WriteLine();
        }

        public static void Sorting(List<int> numbers)
        {
            // Declarative syntax
            var sortedNumbers = from num in numbers
                                orderby num descending
                                select num;


            sortedNumbers.ToList().ForEach(x => Console.Write("{0} ", x));
            Console.WriteLine();

            // Method call syntax
            var sortedNumbers2 = numbers.OrderByDescending(x => x);

            sortedNumbers2.ToList().ForEach(x => Console.Write("{0} ", x));
            Console.WriteLine();
        }

        public static void Grouping(List<int> numbers)
        {
            // Declarative syntax
            var numberGroups = from n in numbers
                               group n by n % 5 into g
                               select new
                               {
                                   Remainder = g.Key,
                                   Numbers = g
                               };

            foreach (var numberGroup in numberGroups.ToList())
            {
                Console.Write("Group with reminder {0}: ", numberGroup.Remainder);
                foreach (var number in numberGroup.Numbers)
                {
                    Console.Write("{0} ", number);
                }
                Console.WriteLine();
            }
        }

        public static void Aggregators(List<int> numbers)
        {
            double average = numbers.Average();

            Console.WriteLine("Average: {0}", average);

            int sum = numbers.Sum(x => (numbers.Min() + numbers.Max()) * x);

            Console.WriteLine("Some kind of sum: {0}", sum);
        }
    }
}