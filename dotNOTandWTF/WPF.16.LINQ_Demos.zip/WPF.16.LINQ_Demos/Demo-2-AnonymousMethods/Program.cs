﻿using System;

namespace Demo_2_AnonymousMethods
{
    public delegate void Alert(string message);

    class Program
    {
        static void AlertMethod(string message)
        {
            Console.WriteLine(message);
        }

        static void Main()
        {
            // Delegate C# 1.0 style
            Alert alertDelegate1 = new Alert(AlertMethod);
            alertDelegate1("Delegate in C# 1.0 style (using named method)");

            // Delegate C# 2.0 style
            Alert alertDelegate2 = delegate(string message)
            {
                Console.WriteLine(message);
            };

            alertDelegate2("Delegate in C# 2.0 style (using anonymous method)");

            // Delegate C# 3.0 style
            Alert alertDelegate3 = (message) => Console.WriteLine(message);

            alertDelegate3("Delegate in C# 3.0 style (using lambda expression)");
        }
    }
}