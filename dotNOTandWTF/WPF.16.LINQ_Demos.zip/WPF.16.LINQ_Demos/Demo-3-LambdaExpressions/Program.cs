﻿using System;

namespace Demo_3_LambdaExpressions
{
    public delegate void Alert(string message);

    class Program
    {
        private static Alert expression;

        static void Main()
        {
            expression = x => Console.WriteLine(x);
        
            expression.Invoke("      Test message.");

            expression = x => 
                             {
                                 if (!String.IsNullOrEmpty(x))
                                 {
                                     x = x.TrimStart();
                                 }
                                 Console.WriteLine(x);
                             };

            expression.Invoke("      Test message.");

            string externalMessage = "ExternalMessage";
            
            expression = x => Console.WriteLine(externalMessage);

            AlertWithExternalMessage();
        }

        static void AlertWithExternalMessage()
        {
            expression(null);
        }
    }
}