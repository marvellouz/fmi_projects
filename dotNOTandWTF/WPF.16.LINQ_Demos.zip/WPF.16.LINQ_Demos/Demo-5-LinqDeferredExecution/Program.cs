﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Demo_5_LinqDeferred
{
    class Program
    {
        static void Main()
        {
            List<int> numbers = new List<int>();

            for (int i = 0; i < 100; i++)
            {
                numbers.Add(i);
            }

            var deferredExecuted = from n in numbers
                                  where IsEven(n)
                                  select n;

            List<int> ints = deferredExecuted.ToList();

            Console.WriteLine(ints[0]);
        }

        static bool IsEven(int num)
        {
            bool isEven = num % 2 == 0;
            Console.WriteLine("{0} - {1}", num, isEven);

            return isEven;
        }
    }
}