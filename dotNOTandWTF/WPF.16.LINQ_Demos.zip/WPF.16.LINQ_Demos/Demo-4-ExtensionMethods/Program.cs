﻿using System;

namespace Demo_4_ExtensionMethods
{
    class Program
    {
        static void Main()
        {
            const string longText = "My text is too long to fit in the user interface.";
            Console.WriteLine(longText.Substring(22, "..."));
        }
    }

    static class StringExtensions
    {
        public static string Substring(this string text, int maxLength, string suffix)
        {
            string result = text;

            if (!String.IsNullOrEmpty(result) &&
                result.Length > maxLength)
            {
                result = string.Format("{0}{1}", result.Substring(0, maxLength), suffix ?? String.Empty);
            }

            return result;
        }
    }
}