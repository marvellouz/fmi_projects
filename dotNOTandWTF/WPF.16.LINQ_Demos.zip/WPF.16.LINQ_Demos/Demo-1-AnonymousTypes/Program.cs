﻿using System;

class Program
{
    static void Main()
    {
        var student = new { Name = "Joe", Age = 22 };

        Console.WriteLine("Unnamed student type: {0} - {1}", student.Name, student.Age);

        Student namedStudent = new Student() { Name = student.Name, Age = student.Age };

        Console.WriteLine("Named student type: {0} - {1}", namedStudent.Name, namedStudent.Age);

        var secondStudent = new { Name = "Brad", Age = 19 };

        Console.WriteLine("Second unnamed student type: {0} - {1}", secondStudent.Name, secondStudent.Age);

        // This operation is not permitted
        //Student a = (Student) student;
        
        // This operation is permitted
        student = secondStudent;

        Console.WriteLine("Copied student: {0} - {1}", student.Name, student.Age);
    }

    public class Student
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}