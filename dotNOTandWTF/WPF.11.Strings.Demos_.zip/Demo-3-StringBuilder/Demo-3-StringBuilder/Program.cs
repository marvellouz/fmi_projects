﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        StringConcatenationSpeedTest();
    }

    public static void StringConcatenationSpeedTest()
    {
        Stopwatch speedMeter = new Stopwatch();

        speedMeter.Start();

        string text = String.Empty;
        for (int i = 0; i < 30000; i++)
        {
            text += i;
        }

        speedMeter.Stop();
        Console.WriteLine("String concatenation time: {0}", speedMeter.Elapsed);

        speedMeter.Reset();
        speedMeter.Start();

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < 30000; i++)
        {
            builder.Append(i);
        }

        speedMeter.Stop();
        Console.WriteLine("String builder time: {0}", speedMeter.Elapsed);
    }
}
