﻿using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        ShowLine(); Console.WriteLine(Char.IsControl('\n'));
        ShowLine(); Console.WriteLine(Char.IsDigit('9'));
        ShowLine(); Console.WriteLine(Char.IsLetter('A'));
        ShowLine(); Console.WriteLine(Char.IsLetterOrDigit('O'));
        ShowLine(); Console.WriteLine(Char.IsNumber('I'));
        ShowLine(); Console.WriteLine(Char.IsPunctuation('.'));
        ShowLine(); Console.WriteLine(Char.IsSeparator('-'));
        ShowLine(); Console.WriteLine(Char.IsSymbol('⅔'));
        ShowLine(); Console.WriteLine(Char.IsWhiteSpace(' '));
        ShowLine(); Console.WriteLine(Char.GetUnicodeCategory('♥'));

        ShowLine(); Console.WriteLine(Char.IsLower('a'));
        ShowLine(); Console.WriteLine(Char.IsUpper('A'));

        ShowLine(); Console.WriteLine(Char.ToLower('A'));
        ShowLine(); Console.WriteLine(Char.ToUpper('a'));
    }

    private static void ShowLine()
    {
        StackFrame stackFrame = new StackFrame(1, true);

        int line = stackFrame.GetFileLineNumber();

        Console.Write(line + ": ");
    }
}