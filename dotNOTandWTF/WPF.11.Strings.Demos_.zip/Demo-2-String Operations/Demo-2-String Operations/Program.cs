﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

class Program
{
    static void Main()
    {
        string text = "This is my string. My string is amazing!";

        Console.WriteLine(text.Length);

        int startIndex = text.IndexOf("string");
        Console.WriteLine(startIndex);

        int lastIndex = text.LastIndexOf("string");
        Console.WriteLine(lastIndex);

        int index = text.IndexOf("horse");
        Console.WriteLine(index);

        string substring = text.Substring(19, 21);
        Console.WriteLine(substring);

        Console.WriteLine(text.StartsWith("This"));

        Console.WriteLine(text.EndsWith("!"));

        Console.WriteLine(text.ToUpper());

        Console.WriteLine(text.ToLower());

        PrintWords(text);

        Console.WriteLine(text.PadLeft(50, '#'));

        Console.WriteLine(text.PadRight(50, '#'));

        Console.WriteLine("  my username  ".Trim());

        Console.WriteLine(text.Insert(11, "inserted "));

        Console.WriteLine(text.Remove(8, 3));

        Console.WriteLine(text.Replace("string", "horse"));

        Console.WriteLine(String.Format("This is my {0}. My {0} is {1}!", "string", "amazing"));
    }

    public static void PrintWords(string text)
    {
        Console.WriteLine("----------");
        char[] separators = new char[] { ' ', '.', '!' };
        string[] words = text.Split(separators);//,StringSplitOptions.RemoveEmptyEntries

        foreach (string word in words)
        {
            Console.WriteLine(word);
        }
        Console.WriteLine("----------");

        string joinWords = String.Join(" + ", words);
        Console.WriteLine(joinWords);
    }
}
