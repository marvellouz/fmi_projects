﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


class Program
{
    static unsafe void Main()
    {
        string first = "This string is interned";
        string second = "This string is interned";

        Console.WriteLine(String.ReferenceEquals(first, second));

        second = "This string";
        second += " is interned";

        Console.WriteLine(String.ReferenceEquals(first, second));

        second = String.Intern(second);

        Console.WriteLine(String.ReferenceEquals(first, second));
    }
}
