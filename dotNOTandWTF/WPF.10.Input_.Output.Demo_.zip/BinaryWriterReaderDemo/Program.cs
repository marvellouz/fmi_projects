﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BinaryWriterReaderDemo
{

    class Program
    {
        static void Main(string[] args)
        {
            char c = 'П';
            int i = 15;
            string s = "Hello";

            using (FileStream file = new FileStream("file.txt", FileMode.Create))
            {
                using (BinaryWriter writer = new BinaryWriter(file))//, Encoding.UTF32))
                {
                    writer.Write(c);
                    writer.Write(i);
                    writer.Write(s);
                }
            }

            using (FileStream file = new FileStream("file.txt", FileMode.Open, FileAccess.Read))
            {
                using (BinaryReader reader = new BinaryReader(file))//, Encoding.UTF32))
                {
                    char nc = reader.ReadChar();
                    int ni = reader.ReadInt32();
                    string ns = reader.ReadString();

                    Console.WriteLine(nc);
                    Console.WriteLine(ni);
                    Console.WriteLine(ns);
                }
            }
        }
    }
}
