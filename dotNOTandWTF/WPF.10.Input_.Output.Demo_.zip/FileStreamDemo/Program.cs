﻿using System;
using System.IO;
using System.Text;

namespace FileStreamDemo
{
    class Program
    {
        public static void Main()
        {
            //Demo1();
            Demo2();
        }

        private static void Demo1()
        {
            string path = "TestFile.txt";

            using (FileStream file = File.Create(path))
            {
                AddText(file, "This is some text");
                AddText(file, "This is some more text,");
                AddText(file, "\r\nand this is on a new line");
                AddText(file, "\r\n\r\nThe following is a subset of characters:\r\n");

                for (int i = 1; i < 120; i++)
                {
                    AddText(file, Convert.ToChar(i).ToString());
                }
            }

            using (FileStream fs = File.OpenRead(path))
            {
                byte[] buffer = new byte[1024];
                UTF8Encoding temp = new UTF8Encoding(true);
                while (fs.Read(buffer, 0, buffer.Length) > 0)
                {
                    Console.WriteLine(Encoding.UTF8.GetString(buffer));
                }
            }
        }

        private static void AddText(FileStream file, string value)
        {
            byte[] info = Encoding.UTF8.GetBytes(value);
            file.Write(info, 0, info.Length);
        }

        private static void Demo2()
        {
            string inputFilePath = "InputFile.txt";
            string outputFilePath = "OutputFile.txt";

            using (var inputFile = new FileStream(inputFilePath, FileMode.Open))
            {
                using (var outputFile = new FileStream(outputFilePath, FileMode.Create))
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead = 0;

                    do
                    {
                        bytesRead = inputFile.Read(buffer, 0, buffer.Length);
                        outputFile.Write(buffer, 0, bytesRead);
                    }
                    while (bytesRead == buffer.Length);
                }
            }
        }
    }
}
