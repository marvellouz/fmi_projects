﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace EncodingDemo
{
    /// <summary>
    /// Записва кода който въвеждаме от клавиатурата в текстов файл,
    /// използвайки определено кодиране. Итерирането продължава до въвеждане на празен низ.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            using (StreamWriter writer = new StreamWriter("log.txt", true, Encoding.BigEndianUnicode))
            {
                writer.NewLine = " && ";
                do
                {
                    line = Console.ReadLine();
                    writer.WriteLine(line);
                }
                while (!string.IsNullOrEmpty(line));
            }
        }
    }
}
