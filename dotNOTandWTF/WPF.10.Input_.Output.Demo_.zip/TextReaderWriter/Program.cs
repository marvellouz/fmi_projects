﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TextReaderWriter
{
    /// <summary>
    /// Програма която изписва на 
    /// екрана собствения си текст.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            using (StreamReader reader = new StreamReader(@"..\..\Program.cs"))
            {
                string line;
                do
                {
                    line = reader.ReadLine();
                    if (line != null)
                    {
                        Console.WriteLine(line);
                    }
                }
                while (line != null);
            }
        }
    }
}
