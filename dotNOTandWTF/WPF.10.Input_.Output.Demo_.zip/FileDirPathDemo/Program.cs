﻿using System;
using System.IO;

namespace FileDirPathDemo
{
    public class TextDirs
    {
        public static void Main(string[] args)
        {
            Demo1();
            //Demo2();
        }

        private static void Demo1()
        {
            string directoryName = @"c:\";

            DirectoryInfo directory = new DirectoryInfo(directoryName);
            foreach (FileSystemInfo fileSystemInfo in directory.GetFileSystemInfos("*cool*"))
            {
                string text = string.Empty;

                // Creation time
                text += fileSystemInfo.CreationTime.ToString() + '\t';

                // Type and Size
                if (fileSystemInfo is DirectoryInfo)
                {
                    text += "<DIR>" + '\t';
                    text += "     " + '\t';
                }
                else
                {
                    text += "      " + '\t';
                    FileInfo fileInfo = (FileInfo)fileSystemInfo;
                    text += String.Format(fileInfo.Length.ToString(), "{0}") + '\t';
                }

                // Name
                text += fileSystemInfo.Name;
                Console.WriteLine(text);
            }
        }

        private static void Demo2()
        {
            string filePath = @"c:\test.txt";

            // get file attributes
            FileAttributes fileAttributes = File.GetAttributes(filePath);

            // clear all file attributes
            File.SetAttributes(filePath, FileAttributes.Normal);

            // set just only archive and read only attributes (no other attribute will set)
            File.SetAttributes(filePath, FileAttributes.Archive | FileAttributes.ReadOnly);

            // check whether a file is read only
            bool isReadOnly = ((File.GetAttributes(filePath) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly);

            // check whether a file is hidden
            bool isHidden = ((File.GetAttributes(filePath) & FileAttributes.Hidden) == FileAttributes.Hidden);

            // check whether a file has archive attribute
            bool isArchive = ((File.GetAttributes(filePath) & FileAttributes.Archive) == FileAttributes.Archive);

            // check whether a file is system file
            bool isSystem = ((File.GetAttributes(filePath) & FileAttributes.System) == FileAttributes.System);

            // set (add) hidden attribute (hide a file)
            File.SetAttributes(filePath, File.GetAttributes(filePath) | FileAttributes.Hidden);

            // set (add) both archive and read only attributes
            File.SetAttributes(filePath, File.GetAttributes(filePath) | (FileAttributes.Archive | FileAttributes.ReadOnly));

            // delete/clear hidden attribute
            File.SetAttributes(filePath, File.GetAttributes(filePath) & ~FileAttributes.Hidden);

            // delete/clear archive and read only attributes
            File.SetAttributes(filePath, File.GetAttributes(filePath) & ~(FileAttributes.Archive | FileAttributes.ReadOnly));

        }
    }
}
