﻿using System;
using System.IO;

namespace Playground
{
	public class FilesLibrary
	{
		private static readonly string LogFileName = "LibraryLog.log";

		private string workingDirectoryPath;
		private string logFilePath;
		private string directoryPathToMonitor;
		private FilesLibraryOrganiser libraryOrganiser;

		public FilesLibrary(string folderPathToMonitor)
		{
			this.workingDirectoryPath = Directory.GetCurrentDirectory();
			this.logFilePath = Path.Combine(this.workingDirectoryPath, LogFileName);
			this.directoryPathToMonitor = folderPathToMonitor;
			this.libraryOrganiser = new FilesLibraryOrganiser(this.workingDirectoryPath);
		}

		public void Start()
		{
			using (var fileSystemWatcher = this.CreateFileSystemWatcher())
			{
				fileSystemWatcher.EnableRaisingEvents = true;

				// Never do this in real world!
				while (true) ;
			}
		}

		private FileSystemWatcher CreateFileSystemWatcher()
		{
			var fileSystemWatcher = new FileSystemWatcher(this.directoryPathToMonitor);

			fileSystemWatcher.Created += new FileSystemEventHandler(fileSystemWatcher_EventHandler);
			fileSystemWatcher.Changed += new FileSystemEventHandler(fileSystemWatcher_EventHandler);
			fileSystemWatcher.Deleted += new FileSystemEventHandler(fileSystemWatcher_EventHandler);

			fileSystemWatcher.EnableRaisingEvents = true;

			return fileSystemWatcher;
		}

		private void fileSystemWatcher_EventHandler(object sender, FileSystemEventArgs e)
		{
			if (this.IsFile(e.FullPath))
			{
				switch (e.ChangeType)
				{
					case WatcherChangeTypes.Changed:
						this.libraryOrganiser.ChangeFileInLibrary(e.FullPath);
						break;
					case WatcherChangeTypes.Created:
						this.libraryOrganiser.AddFileToLibrary(e.FullPath);
						break;
					case WatcherChangeTypes.Deleted:
						this.libraryOrganiser.DeleteFileFromLibrary(e.FullPath);
						break;
					default:
						break;
				}

				this.LogEvent(e.ChangeType, e.FullPath);
			}
		}

		private bool IsFile(string path)
		{
			return !string.IsNullOrEmpty(Path.GetExtension(path));
		}

		private void LogEvent(WatcherChangeTypes changeEventType, string filePath)
		{
			using (var logFileWriter = new StreamWriter(this.logFilePath))
			{
				logFileWriter.WriteLine("{0}: {1} {2}", DateTime.Now, changeEventType.ToString(), filePath);
			}
		}
	}
}
