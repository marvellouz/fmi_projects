﻿using System;
using System.IO;

namespace Playground
{
	public class FilesLibraryOrganiser
	{
		private enum FileLibraryOperationType
		{
			Create,
			Change,
			Rename,
			Delete
		}

		private static readonly string MusicDirectoryName = "Music";
		private static readonly string ImagesDirectoryName = "Pictures";
		private static readonly string MiscDirectoryName = "Misc";

		private string libraryDirectoryPath;
		private string musicDirectoryPath;
		private string imagesDirecotryPath;
		private string miscDirectoryPath;

		public FilesLibraryOrganiser(string libraryDirectoryPath)
		{
			this.libraryDirectoryPath = libraryDirectoryPath;
			this.musicDirectoryPath = Path.Combine(this.libraryDirectoryPath, MusicDirectoryName);
			this.imagesDirecotryPath = Path.Combine(this.libraryDirectoryPath, ImagesDirectoryName);
			this.miscDirectoryPath = Path.Combine(this.libraryDirectoryPath, MiscDirectoryName);
		}

		internal void AddFileToLibrary(string filePath)
		{
			this.PerformOperation(FileLibraryOperationType.Create, filePath);
		}

		internal void ChangeFileInLibrary(string filePath)
		{
			this.PerformOperation(FileLibraryOperationType.Change, filePath);
		}

		internal void DeleteFileFromLibrary(string filePath)
		{
			this.PerformOperation(FileLibraryOperationType.Delete, filePath);
		}

		private void PerformOperation(FileLibraryOperationType operationType, string filePath)
		{
			string extension = Path.GetExtension(filePath);

			switch (extension)
			{
				case ".mp3":
					this.PerformMusicFileOperation(operationType, filePath);
					break;
				case ".jpg":
				case ".jpeg":
					this.PerformImageFileOperation(operationType, filePath);
					break;
				default:
					this.PerformMiscFileOperation(operationType, filePath);
					break;
			}
		}

		private void PerformMusicFileOperation(FileLibraryOperationType operationType, string filePath)
		{
			string libraryFilePath = this.GetMusicLibraryFilePath(filePath);
			this.PerformFileOperation(operationType, filePath, libraryFilePath);
		}

		private string GetMusicLibraryFilePath(string filePath)
		{
			string fileName = Path.GetFileName(filePath);
			string musicLibrarySubDirPath = Path.Combine(this.musicDirectoryPath, fileName[0].ToString());

			return Path.Combine(musicLibrarySubDirPath, fileName);
		}

		private void PerformImageFileOperation(FileLibraryOperationType operationType, string filePath)
		{
			string libraryFilePath = this.GetImageLibraryFilePath(filePath);
			this.PerformFileOperation(operationType, filePath, libraryFilePath);
		}

		private string GetImageLibraryFilePath(string filePath)
		{
			string fileName = Path.GetFileName(filePath);
			DateTime fileCreationTime = File.GetCreationTime(filePath);
			string imageLibrarySubDirName = string.Format("{0}-{1}-{2}", fileCreationTime.Year, fileCreationTime.Month, fileCreationTime.Day);
			string imageLibrarySubDirPath = Path.Combine(this.imagesDirecotryPath, imageLibrarySubDirName);

			return Path.Combine(imageLibrarySubDirPath, fileName);
		}

		private void PerformMiscFileOperation(FileLibraryOperationType operationType, string filePath)
		{
			string libraryFilePath = this.GetMiscLibraryFilePath(filePath);
			this.PerformFileOperation(operationType, filePath, libraryFilePath);
		}

		private string GetMiscLibraryFilePath(string filePath)
		{
			string fileName = Path.GetFileName(filePath);

			return Path.Combine(this.miscDirectoryPath, fileName);
		}

		private void PerformFileOperation(FileLibraryOperationType operationType, string sourceFilePath, string libraryFilePath)
		{
			switch (operationType)
			{
				case FileLibraryOperationType.Create:
				case FileLibraryOperationType.Change:
					this.EnsureLibraryDirectoryExists(libraryFilePath);
					File.Copy(sourceFilePath, libraryFilePath, true);
					break;
				case FileLibraryOperationType.Delete:
					// This doesn't work for images because we cannot get the creation time of already deleted file :)
					// Try to think of workaround.
					File.Delete(libraryFilePath);
					break;
				default:
					break;
			}
		}

		private void EnsureLibraryDirectoryExists(string libraryFilePath)
		{
			string libraryDirectoryPath = Path.GetDirectoryName(libraryFilePath);
			if (!Directory.Exists(libraryDirectoryPath))
			{
				Directory.CreateDirectory(libraryDirectoryPath);
			}
		}
	}
}
