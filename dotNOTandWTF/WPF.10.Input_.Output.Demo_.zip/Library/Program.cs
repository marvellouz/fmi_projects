﻿using System;
namespace Playground
{
    class Program
    {
        static void Main(string[] args)
        {
            var libraryDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            var filesLibrary = new FilesLibrary(libraryDirectory);

            filesLibrary.Start();
        }
    }
}
