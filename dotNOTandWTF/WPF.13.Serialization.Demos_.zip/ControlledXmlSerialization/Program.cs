﻿using System;
using System.Xml.Serialization;
using System.Text;
using System.IO;

namespace ControlledXmlSerialization
{
	class Program
	{
		static void Main(string[] args)
		{
			var company = new Company();
			company.Employees = new Employee[4];
			company.Owners = new Manager[2];

			company.Employees[0] = new Employee { Name = "бай Иван", YearsOfEmployment = 12 };
			company.Employees[1] = new Employee { Name = "програмист Пешо хакера", YearsOfEmployment = 1 };
			company.Employees[2] = new TeamLead { Name = "Scott Hanselman", YearsOfEmployment = 4, TeamName = "Машините", TeamSize = 3 };
			company.Employees[3] = new Manager { Name = "г-н Петров", YearsOfEmployment = 7, Level = 3 };

			company.Owners[0] = new Manager { Name = "Киро", YearsOfEmployment = 20, Level = 100 };
			company.Owners[1] = new Manager { Name = "Сергей", YearsOfEmployment = 20, Level = 100 };

			using (var writer = new StreamWriter("company.xml"))
			{
				var serializer = new XmlSerializer(typeof(Company));
				serializer.Serialize(writer, company);
			}

			using (var reader = new StreamReader("company.xml"))
			{
				var serializer = new XmlSerializer(typeof(Company));
				Company newCompany = (Company)serializer.Deserialize(reader);
				Console.WriteLine(newCompany.ToString());
			}
		}
	}

	public class Company
	{
		[XmlArray(ElementName = "Slaves")]
		[XmlArrayItem(Type = typeof(Employee))]
		[XmlArrayItem(Type = typeof(TeamLead))]
		[XmlArrayItem(Type = typeof(Manager))]
		public Employee[] Employees { get; set; }

		[XmlElement(ElementName = "Bosses")]
		public Manager[] Owners { get; set; }

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();

			sb.AppendLine("Slaves:");
			foreach (var employee in this.Employees)
			{
				sb.AppendFormat("\t{0}", employee.ToString());
				sb.AppendLine();
			}

			sb.AppendLine();
			sb.AppendLine("Bosses:");
			foreach (var owner in this.Owners)
			{
				sb.AppendFormat("\t{0}", owner.ToString());
				sb.AppendLine();
			}

			return sb.ToString();
		}
	}

	public class Employee
	{
		public string Name { get; set; }

		[XmlIgnore]
		public int YearsOfEmployment { get; set; }

		private decimal Salary { get; set; }

		public override string ToString()
		{
			return string.Format("{0} - Employee", this.Name);
		}
	}

	public class TeamLead : Employee
	{
		public string TeamName { get; set; }

		[XmlElement(ElementName = "TeamMemebersCount")]
		public int TeamSize { get; set; }

		public override string ToString()
		{
			return string.Format("{0} - Team Lead of {1} team", this.Name, this.TeamName);
		}
	}

	public class Manager : Employee
	{
		public int Level { get; set; }

		public override string ToString()
		{
			return string.Format("{0} - Manager of level {1}", this.Name, this.Level);
		}
	}
}
