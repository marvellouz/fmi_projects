﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace ControledSerialization
{
	class Program
	{
		static void Main(string[] args)
		{
			var circle = new Circle(3.0);
			Circle newCircle = null;

			Console.WriteLine("Original circle: {0}", circle);

			var formatter = new BinaryFormatter();
			using (var stream = File.OpenWrite("File.bin"))
			{
				formatter.Serialize(stream, circle);
			}

			using (var stream = File.OpenRead("File.bin"))
			{
				newCircle = (Circle)formatter.Deserialize(stream);
			}

			Console.WriteLine("New circle: {0}", newCircle);
		}
	}

	[Serializable]
	class Circle
	{
		[OptionalField]
		private string title;

		private double radius;

		[NonSerialized]
		private double perimeter;

		[NonSerialized]
		private double area;

		public Circle(double radius)
		{
			this.radius = radius;
			this.InitializeState();
		}

		private void InitializeState()
		{
			this.perimeter = 2 * Math.PI * this.radius;
			this.area = Math.PI * this.radius * this.radius;
		}

		[OnDeserialized]
		void OnDeserialized(StreamingContext context)
		{
			this.InitializeState();
		}

		public override string ToString()
		{
			return String.Format("Radius: {0}, Perimeter: {1}, Area: {2}", this.radius, this.perimeter, this.area);
		}
	}
}
