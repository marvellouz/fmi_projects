﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace Demo
{
	class Program
	{
		[STAThread()]
		static void Main(string[] args)
		{
			using (var reader = new StreamReader(@"..\..\ApplicationUI.xml"))
			{
				var serializer = new XmlSerializer(typeof(Window));
				var window = (Window)serializer.Deserialize(reader);

				window.Show();
			}
		}
	}
}
