﻿using System.Xml.Serialization;

namespace Demo
{
	public class Window : Control
	{
		[XmlAttribute]
		public string Title { get; set; }

		[XmlAttribute]
		public int Width { get; set; }

		[XmlAttribute]
		public int Height { get; set; }

		[XmlAttribute]
		public Color Background { get; set; }

		[XmlElement(ElementName = "StackPanel")]
		public StackPanel Panel { get; set; }

		public void Show()
		{
			System.Windows.Window window = (System.Windows.Window)this.GetUIInstance();
			System.Windows.Application application = new System.Windows.Application();

			application.Run(window);
		}

		internal override System.Windows.UIElement GetUIInstance()
		{
			System.Windows.Window instance = new System.Windows.Window();
			instance.Title = this.Title;
			instance.Width = this.Width;
			instance.Height = this.Height;

			switch (this.Background)
			{
				case Color.Red:
					instance.Background = System.Windows.Media.Brushes.Red;
					break;
				case Color.Green:
					instance.Background = System.Windows.Media.Brushes.Green;
					break;
				case Color.Blue:
					instance.Background = System.Windows.Media.Brushes.Blue;
					break;
				case Color.Orange:
					instance.Background = System.Windows.Media.Brushes.Orange;
					break;
				case Color.Yellow:
					instance.Background = System.Windows.Media.Brushes.Yellow;
					break;
				case Color.Pink:
					instance.Background = System.Windows.Media.Brushes.Pink;
					break;
				default:
					break;
			}

			instance.Content = (this.Panel as Control).GetUIInstance();

			return instance;
		}
	}
}
