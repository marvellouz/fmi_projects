﻿using System.Xml.Serialization;

namespace Demo
{
	public class StackPanel : Control
	{
		[XmlAttribute]
		public HorizontalAlignment HorizontalAlignment { get; set; }

		[XmlAttribute]
		public VerticalAlignment VerticalAlignment { get; set; }

		[XmlArray()]
		[XmlArrayItem(Type = typeof(Button))]
		public Control[] Content { get; set; }

		internal override System.Windows.UIElement GetUIInstance()
		{
			System.Windows.Controls.StackPanel instance = new System.Windows.Controls.StackPanel();

			switch (this.HorizontalAlignment)
			{
				case HorizontalAlignment.Left:
					instance.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
					break;
				case HorizontalAlignment.Center:
					instance.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
					break;
				case HorizontalAlignment.Right:
					instance.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
					break;
				default:
					break;
			}

			switch (this.VerticalAlignment)
			{
				case VerticalAlignment.Top:
					instance.VerticalAlignment = System.Windows.VerticalAlignment.Top;
					break;
				case VerticalAlignment.Center:
					instance.VerticalAlignment = System.Windows.VerticalAlignment.Center;
					break;
				case VerticalAlignment.Bottom:
					instance.VerticalAlignment = System.Windows.VerticalAlignment.Bottom;
					break;
				default:
					break;
			}

			foreach (var control in this.Content)
			{
				instance.Children.Add((System.Windows.UIElement)control.GetUIInstance());
			}

			return instance;
		}
	}
}
