﻿using System.Xml.Serialization;

namespace Demo
{
	public class Button : Control
	{
		[XmlAttribute]
		public string Id { get; set; }

		[XmlAttribute]
		public string Text { get; set; }

		[XmlAttribute]
		public double Width { get; set; }

		[XmlAttribute]
		public double Height { get; set; }

		[XmlAttribute]
		public double Opacity { get; set; }

		internal override System.Windows.UIElement GetUIInstance()
		{
			System.Windows.Controls.Button instance = new System.Windows.Controls.Button();
			instance.Name = this.Id;
			instance.Content = this.Text;
			instance.Width = this.Width;
			instance.Height = this.Height;
			instance.Opacity = this.Opacity;

			return instance;
		}
	}
}
