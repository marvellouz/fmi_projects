﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace BasicXmlSerialization
{
	class Program
	{
		static void Main(string[] args)
		{
			var student = new Student();

			student.Name.FirsName = "Ivan";
			student.Name.LastName = "Petrov";
			student.Age = 19;
			student.PhoneNumbers.Add("123456789");
			student.PhoneNumbers.Add("987654321");
			student.PhoneNumbers.Add("121212121");

			using (var file = File.OpenWrite("student.xml"))
			{
				var xmlSerializer = new XmlSerializer(typeof(Student));
				xmlSerializer.Serialize(file, student);
			}

			using (var file = File.OpenRead("student.xml"))
			{
				var xmlSerializer = new XmlSerializer(typeof(Student));
				var newStudent = (Student)xmlSerializer.Deserialize(file);

				Console.WriteLine(newStudent.Name.FirsName);
				Console.WriteLine(newStudent.Name.LastName);
				Console.WriteLine(newStudent.Age);

				foreach (var phoneNumber in newStudent.PhoneNumbers)
				{
					Console.WriteLine(phoneNumber);
				}
			}
		}
	}

	public class Student
	{
		public Student()
		{
			this.Egn = "0000000000";
			this.Name = new Name();
			this.PhoneNumbers = new List<string>();
		}

		public Name Name { get; set; }
		public int Age { get; set; }
		private string Egn { get; set; }
		public List<string> PhoneNumbers { get; set; }
	}

	public class Name
	{
		public string FirsName;
		public string LastName;
	}
}
