﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace BasicSerialization
{
	[Serializable]
	public class MyClass
	{
		public int x = 0;
		public int y = 0;
		public String str = null;
	}

	class Program
	{
		static void Main(string[] args)
		{
			Serialize();
			Deserialize();
		}

		private static void Serialize()
		{
			var obj = new MyClass { x = 1, y = 24, str = "Some String" };
			var formatter = new BinaryFormatter();

			using (var stream = File.OpenWrite("MyFile.bin"))
			{
				formatter.Serialize(stream, obj);
			}
		}

		private static void Deserialize()
		{
			var formatter = new BinaryFormatter();

			MyClass obj = null;
			using (var stream = File.OpenRead("MyFile.bin"))
			{
				obj = (MyClass)formatter.Deserialize(stream);
			}

			Console.WriteLine("x: {0}", obj.x);
			Console.WriteLine("y: {0}", obj.y);
			Console.WriteLine("str: {0}", obj.str);
		}
	}
}
