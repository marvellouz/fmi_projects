﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Panels
{
	/// <summary>
	/// Interaction logic for UniformGridExample.xaml
	/// </summary>
	public partial class UniformGridExample : Window
	{
		private int i = 6;
		public UniformGridExample()
		{
			InitializeComponent();
		}

		private void ButtonAdd_Click(object sender, RoutedEventArgs e)
		{
			this.TestPanel.Children.Add(
				new Button
				{
					Content = "item" + i.ToString(),
					Background = SelectBackground(i)
				});
			i++;
		}

		private void ButtonRemove_Click(object sender, RoutedEventArgs e)
		{
			this.TestPanel.Children.RemoveAt(0);
		}

		private static Brush SelectBackground(int i)
		{
			switch (i % 5)
			{
				case 1: return new SolidColorBrush(Colors.Red);
				case 2: return new SolidColorBrush(Colors.Green);
				case 3: return new SolidColorBrush(Colors.Blue);
				case 4: return new SolidColorBrush(Colors.Cyan);
				default: return new SolidColorBrush(Colors.Magenta);
			}
		}
	}
}
