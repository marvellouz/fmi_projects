﻿using System.Windows;

namespace Panels
{
	/// <summary>
	/// Interaction logic for CanvasExample.xaml
	/// </summary>
	public partial class CanvasExample : Window
	{
		public CanvasExample()
		{
			InitializeComponent();
		}
	}
}
