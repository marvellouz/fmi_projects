﻿using System.Windows;

namespace PanelsComplexDemo
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();
		}

		private void AdditionalInfoButton_Click(object sender, RoutedEventArgs e)
		{
			AdditionalInfoButton.Visibility = Visibility.Collapsed;
			AdditionalInfo.Visibility = Visibility.Visible;
		}

		private void SubmitInfoButton_Click(object sender, RoutedEventArgs e)
		{
			SubmitInfoButton.Visibility = Visibility.Collapsed;
			SubmitInfo.Visibility = Visibility.Visible;
		}

		private void HideAdditionalInfoButton_Click(object sender, RoutedEventArgs e)
		{
			AdditionalInfo.Visibility = Visibility.Collapsed;
			AdditionalInfoButton.Visibility = Visibility.Visible;
		}

		private void HideSubmitInfoButton_Click(object sender, RoutedEventArgs e)
		{
			SubmitInfo.Visibility = Visibility.Collapsed;
			SubmitInfoButton.Visibility = Visibility.Visible;
		}

		private void ExitMenuItem_Click(object sender, RoutedEventArgs e)
		{
			Application.Current.Shutdown();
		}

		private void AdditionalInfoMenuItem_Click(object sender, RoutedEventArgs e)
		{
			if (this.AdditionalInfoMenuItem.IsChecked)
			{
				AdditionalInfo.Visibility = Visibility.Collapsed;
				AdditionalInfoButton.Visibility = Visibility.Collapsed;
			}
			else
			{
				AdditionalInfo.Visibility = Visibility.Visible;
			}
			this.AdditionalInfoMenuItem.IsChecked = !this.AdditionalInfoMenuItem.IsChecked;
		}

		private void SubmitInfoMenuItem_Click(object sender, RoutedEventArgs e)
		{
			if (this.SubmitInfoMenuItem.IsChecked)
			{
				SubmitInfo.Visibility = Visibility.Collapsed;
				SubmitInfoButton.Visibility = Visibility.Collapsed;
			}
			else
			{
				SubmitInfo.Visibility = Visibility.Visible;
			}
			this.SubmitInfoMenuItem.IsChecked = !this.SubmitInfoMenuItem.IsChecked;
		}

		private void FirstNameTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
		{
			FirstNameIndicator.Visibility = FirstNameTextBox.Text != string.Empty ? Visibility.Visible : Visibility.Collapsed;
		}

		private void SecondNameTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
		{
			SecondNameIndicator.Visibility = SecondNameTextBox.Text != string.Empty ? Visibility.Visible : Visibility.Collapsed;
		}

		private void ThirdNameTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
		{
			ThirdNameIndicator.Visibility = ThirdNameTextBox.Text != string.Empty ? Visibility.Visible : Visibility.Collapsed;
		}
	}
}